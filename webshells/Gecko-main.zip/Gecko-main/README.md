
<div align="center"><h1>Gecko Web Backdoor</h1></div>
<br>

<div align="center">
  
![licence](https://img.shields.io/badge/LICENE-GPL2.0-ebcb8b?style=flat-square)
![version](https://img.shields.io/badge/VERSION-1.0.2-a3be8c?style=flat-square)
  
 </div>
<br>

<samp>

* Bypass 403
* Bypass 404
* Bypass 500
* Bypass litespeed
* Bypass blankphp
* Bypass downloaded

</samp>

<div align="center"><h1>Features</h1></div>

<samp>

* Linux Exploit Suggester
* Backdoor Destroyer
* Auto Root > Pwnkit 
* Lock File
* Lock Shell
* Add UserName > ROOT EDITION
* Add UNLOCK SHELL
* Add Backconnect
* Add Hash identifier
* Add adminer
* Add Cpanel RESET
* Wordpress add admin user
* Add Compressor zip
* Add Decomporessor Archive
* No detect shell


</samp>
  
<div align="center"><h1>Fixed</h1></div>

<samp>
  
* Fixed Bug On Backdoor Destroyer
* Fixed Bug On Auto Root!

</samp>

<div align="center"><h1>Read this</h1></div>

<samp>

I'm not responsible for what you guys do using my tools!, Segala macam backdoor yang membawa gecko dll, gecko asli hanya di github MadExploits

if you want to using auto root please type `root` for older version `gecko-old.php`

Upload this `gecko.php` To Your Target!


<div align="center">
<img src="https://raw.githubusercontent.com/MadExploits/Gecko/main/image.png">  
</div>


<div align="center">
 <h1> Support me : </h1>
<a href="https://www.buymeacoffee.com/muhsatria"><img src="https://img.buymeacoffee.com/button-api/?text=Buy me a coffee&emoji=☕&slug=muhsatria&button_colour=FFDD00&font_colour=000000&font_family=Comic&outline_colour=000000&coffee_colour=ffffff" /></a>
</div>


Copyright (c) 2023 MrMad
</samp>
